# CS300-Frupal

'CSS' folder for CSS files.
'Scripts' folder for Javascript files.
'Views' folder for html files.

"MapGenerator" folder - Python code that puts map data into map.html 
so when you open map.html in your browser, that data will be in your local storage.

If you don't have python on your computer then run the createJS.exe file.
Otherwise you can run the createJS.py file.

1. In the map folder update the map_file.txt to match what you want.
2. Run either the createJS.exe or createJS.py file.
3. Open map.html (The data in localStorage as 'map')