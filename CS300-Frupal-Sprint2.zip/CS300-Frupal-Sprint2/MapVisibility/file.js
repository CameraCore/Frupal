myFunction([
{
"display": "#"
},
{
"display": "B"
},
{
"display": "C"
}
])
