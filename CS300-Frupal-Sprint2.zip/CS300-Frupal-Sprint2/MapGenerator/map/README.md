# CS300-Frupal

"MapGenerator" folder - Python code that puts map data into index.html 
so when you open index.html in your browser, that data will be in your local storage.

If you don't have python on your computer then run the createJS.exe file.
Otherwise you can run the createJS.py file.

1. In the map folder update the map_file.txt to match what you want.
2. Run either the createJS.exe or createJS.py file.
3. Open index.html (The data is in localStorage)